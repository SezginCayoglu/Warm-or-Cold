﻿using WarmAndCold;
Serialization_Deserialization.LoadPlayersList();
Menu.Start();
